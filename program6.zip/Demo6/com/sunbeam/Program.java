package Demo6.com.sunbeam;

public class Program {

	public static void main(String[] args) {
		//Date dt1 = new Date( ); 
		//dt1.display();
		
		Date dt2 = new Date(1, 1, 2010); 
		dt2.display();
		
		Emp e = new Emp(1, "Ketan", 1000.00,dt2); 
		e.display();
		
		//Emp e2 = new Emp(); 
		//e2.accept();
		//e2.display();
	}

}
