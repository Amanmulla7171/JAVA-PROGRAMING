/**
 * 
 */
package com.assignment2;

/**
 * 
 */
public class point2d {
    private double x;
    private double y;

    public point2d(double x, double y) {
        this.x = x;
        this.y = y;
    }

    public String getDetails() {
        return "Point(" + x + ", " + y + ")";
    }

    public boolean isEqual(point2d other) {
        return this.x == other.x && this.y == other.y;
    }

    public double calculateDistance(point2d other) {
        return Math.sqrt(Math.pow(this.x - other.x, 2) + Math.pow(this.y - other.y, 2));
    }
}