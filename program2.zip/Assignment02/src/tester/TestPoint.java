/**
 * 
 */
package tester;

import com.assignment2.point2d;
import java.util.Scanner;

public class TestPoint {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter coordinates for point 1 : ");
        double x1 = sc.nextDouble();
        double y1 = sc.nextDouble();

        System.out.println("Enter coordinates for point 2 : ");
        double x2 = sc.nextDouble();
        double y2 = sc.nextDouble();

        point2d p1 = new point2d(x1, y1);
        point2d p2 = new point2d(x2, y2);

        System.out.println("Point 1 : " + p1.getDetails());
        System.out.println("Point 2 : " + p2.getDetails());

        if (p1.isEqual(p2)) {
            System.out.println("Both points are same.");
            System.out.println("Distance : " +0);
        } else {
            System.out.println("Points are not equal");
            System.out.println("Distance : " + p1.calculateDistance(p2));
        }

        sc.close();
    }
}