package com.store;
import java.util.Scanner;
import com.store.Customer;
public class Checkarray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number of customer :");
		int counter=sc.nextInt();
		int accnum = 0;
		int beginbalance=0;
		int totalcharg=0;
		int totalcredit=0;
		int creditlimit=0;
		
		
		for(int i=0;i<counter;i++) {
			System.out.println("Enter the information of "+i+"customer");
			
			System.out.println("Enter the Account Number:");
			 accnum=sc.nextInt();
			System.out.println("Enter  balance at the beginning:");
			beginbalance=sc.nextInt();
			System.out.println("Enter  total of all items charged by the customer:");
			totalcharg=sc.nextInt();
			System.out.println("Enter  total of all credits applied to the customer’s:");
			totalcredit=sc.nextInt();
			System.out.println("Enter  allowed credit limit:");
			creditlimit=sc.nextInt();
		}
		Customer c1=new Customer(accnum,beginbalance,totalcharg,totalcredit,creditlimit);
		c1.display();
		int newBalance = c1.getnewbalance();

        System.out.println("New Balance for account " + accnum + ": " + newBalance);

        if (c1.checkthelimit()) {
            System.out.println(" Credit limit exceeded");
        } else {
            System.out.println("Within credit limit");
        }

	}

}
