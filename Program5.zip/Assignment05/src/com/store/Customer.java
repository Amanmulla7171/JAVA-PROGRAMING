package com.store;
import java.util.Scanner;

public class Customer {
	
	
	private int accountnumber;
	private int beginingbalance;
	private int totalcharged;
	private int totalcredit;
	private int creditlimit;
	
	
	
	
	public Customer(int accountnumber, int beginingbalance, int totalcharged, int totalcredit, int creditlimit) {
		
		this.accountnumber = accountnumber;
		this.beginingbalance = beginingbalance;
		this.totalcharged = totalcharged;
		this.totalcredit = totalcredit;
		this.creditlimit = creditlimit;
	}
	
	public Customer() {
		// TODO Auto-generated constructor stub
	}

	public int  getnewbalance(){
		int  newbalance=this.beginingbalance+this.totalcharged-this.totalcredit;
		
		return newbalance;
	}
	public boolean checkthelimit() {
		return getnewbalance()>creditlimit;
	}
	
	public void display() {
		System.out.println("-------------");
	}
	
	 
	
	
	
		
	

}
