package com.store;

import java.util.Scanner;
import com.store.Customer;

public class program {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number of customer :");
		int counter=sc.nextInt();
		
		
		for(int i=0;i<counter;i++) {
			System.out.println("Enter the information of "+i+"customer");
			
			System.out.println("Enter the Account Number:");
			int accountnumber=sc.nextInt();
			System.out.println("Enter  balance at the beginning:");
			int beginingbalance=sc.nextInt();
			System.out.println("Enter  total of all items charged by the customer:");
			int totalcharged=sc.nextInt();
			System.out.println("Enter  total of all credits applied to the customer’s:");
			int totalcredit=sc.nextInt();
			System.out.println("Enter  allowed credit limit:");
			int creditlimit=sc.nextInt();
		}
		 
		
		}
		
}
		