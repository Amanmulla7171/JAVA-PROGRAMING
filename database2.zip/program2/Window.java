package com.last.program2;

import javax.swing.JFrame;

public class Window extends JFrame{
	
	public Window() {
		
		
	}

}
