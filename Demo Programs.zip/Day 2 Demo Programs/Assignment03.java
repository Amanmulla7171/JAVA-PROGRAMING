
public class Assignment03 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		short a=100;
		byte b=(byte) a;
		System.out.println(b);
	}

}
