
public class Assignment04 {

	public static void main(String[] args) {
		//Wrapper classes 
		int a = 24;
		Integer i = new Integer(a); 
		
		// type-conversion 
		double d = i.doubleValue(); 
		// Integer => double 
		
		float f = i.floatValue(); 
		// Integer => float 
		
		byte b = i.byteValue(); 
		//Integer => byte 
		
		// Helper function 
		int max = Integer.max(150, 330); 
		
		System.out.println("Max : "+max);
		int min=Integer.min(12,4);
		System.out.println("Min : "+min);
	}

}
