import java.util.Scanner;

class Employee{
	//Fields 
	private String name; 
	private int empid; 
	private double salary; 
	//methods 
	public void acceptRecord( ) {
		Scanner sc = new Scanner(System.in); 
		System.out.print("Name : ");
		name = sc.nextLine();
		System.out.print("Empid : ");
		empid = sc.nextInt(); 
		System.out.print("Salary : ");
		salary = sc.nextDouble(); 
	}
	public void printRecord( ) {
		System.out.println("Name : "+name);
		System.out.println("Empid : "+empid);
		System.out.println("Salary : "+salary);
	}
}
public class Assignment07 {
	
	public static void main(String[] args) {
		Employee Emp1 = new Employee(); 
		Employee Emp2 = new Employee(); 
		Employee Emp3 = new Employee(); 
	}
	public static void main1(String[] args) {
		Employee emp = new Employee();
		emp.acceptRecord();
		emp.printRecord();
	}
}


