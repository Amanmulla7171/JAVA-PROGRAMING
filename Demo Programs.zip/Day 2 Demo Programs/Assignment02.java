import java.util.Scanner;
public class Assignment02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter Name: ");
		String name = sc.nextLine();
		System.out.print("Enter No: ");
		int no=sc.nextInt();
		System.out.print("Enter Marks: ");
		int mrk=sc.nextInt();
		System.out.println("Name:"+name);
		System.out.println("No:"+no);
		System.out.println("Marks:"+mrk);
		
	}

}
