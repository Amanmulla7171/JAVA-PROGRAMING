import java.util.Scanner;

class Employee{ 
	private String name; 
	private int empid; 
	private double salary; 
	public void acceptRecord( ) {
		Scanner sc = new Scanner(System.in); 
		System.out.print("Name : ");
		this.name = sc.nextLine();
		System.out.print("Empid : ");
		this.empid = sc.nextInt(); 
		System.out.print("Salary : ");
		this.salary = sc.nextDouble(); 
	}
	public void printRecord( ) {
		System.out.println("Name : "+this.name);
		System.out.println("Empid : "+this.empid);
		System.out.println("Salary : "+this.salary);
	}
}
public class Assignment08 {

	public static void main(String[] args) {
		Employee emp = new Employee();
		emp.acceptRecord(); //emp.acceptRecord(emp); 
		emp.printRecord();// emp.printRecord(emp);
	}
}


