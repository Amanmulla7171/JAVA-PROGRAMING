import java.util.Scanner;

class Employee{
	private String name; 
	private int empid; 
	private double salary; 
 
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getSalary() {
		return salary;
	}
	public int getEmpid() {
		return empid;
	}
	public String getName() {
		return name;
	}
	public void acceptRecord( ) {
		Scanner sc = new Scanner(System.in); 
		System.out.print("Name : ");
		this.name = sc.nextLine();
		System.out.print("Empid : ");
		this.empid = sc.nextInt(); 
		System.out.print("Salary : ");
		this.salary = sc.nextDouble(); 
	}

	public void printRecord( ) {
		System.out.println("Name : "+this.name);
		System.out.println("Empid : "+this.empid);
		System.out.println("Salary : "+this.salary);
	}
}
public class Assignment09 {

	public static void main(String[] args) {
		Employee emp = new Employee();
		emp.acceptRecord(); 
		emp.printRecord();
		emp.setSalary(10000.00);
		System.out.println("Updated salary : "+emp.getSalary());
	}
}


