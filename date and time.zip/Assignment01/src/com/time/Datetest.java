package com.time;

public class Datetest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Date date = new Date();
		
	    date.accept();
		date.display();
		
		//Date dt2=null;
		//dt2.accept();
		
		//dt2.display();
		
	}

}
