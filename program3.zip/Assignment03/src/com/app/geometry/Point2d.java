/**
 * 
 */
package com.app.geometry;

/**
 * 
 */  
public class Point2d {


	
	/**
	 * @param args
	 */
	private double x;
	private double y;



	public  Point2d (double x,double y) {
		this.x=x;
		this.y=y;
	}
		
	public String getDetails() {
		return "points("+ x +","+y+")";
	}
	
	public boolean isEquals(Point2d other) {
		// TODO Auto-generated method stub
		return  this.x==(other.x)&&this.y==(other.y) ;
	}

	 public double calculateDistance(Point2d other) {
		 double dx=this.x-other.x;
		 double dy=this.y-other.y;
		 
		 return Math.sqrt(dx*dx+dy*dy);
	 }

	}


