package Experiments;
import java.util.Calendar;
import java.util.GregorianCalendar;
public class Date {
	public static void main(String[] args) {
	        if (args.length != 3) {
	            System.out.println("Usage: java MyCalendar <day> <month> <year>");
	            return;
	        }

	        int day = Integer.parseInt(args[0]);
	        int month = Integer.parseInt(args[1]) - 1; 
	        int year = Integer.parseInt(args[2]);

	        GregorianCalendar cal = new GregorianCalendar(year, month, day);
	        int dayOfWeek = cal.get(Calendar.DAY_OF_WEEK);

	        String dayName = "";
	        switch (dayOfWeek) {
	            case Calendar.SUNDAY: dayName = "Sunday"; break;
	            case Calendar.MONDAY: dayName = "Monday"; break;
	            case Calendar.TUESDAY: dayName = "Tuesday"; break;
	            case Calendar.WEDNESDAY: dayName = "Wednesday"; break;
	            case Calendar.THURSDAY: dayName = "Thursday"; break;
	            case Calendar.FRIDAY: dayName = "Friday"; break;
	            case Calendar.SATURDAY: dayName = "Saturday"; break;
	        }

	        System.out.println("The Day for given date is " + dayName);
	    }
	}


