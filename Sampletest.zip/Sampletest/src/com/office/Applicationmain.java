package com.office;

import java.util.Scanner;
import com.office.Employee;

public class Applicationmain {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int person = 10;
		Employee[] emp = new Employee[person];
		int counter = 0, choice = 0;

		do {
			System.out.println("-------Menu------");
			System.out.println("1.Add employee:");
			System.out.println("2.Display all employee:");
			System.out.println("3.Search by Employee Id:");
			System.out.println("4.Display Employees joined in given Year: ");
			System.out.println("5.Find Employee with Maximum Salary:");
			System.out.println("6.Find Employee with Minimum Salary:");
			System.out.println("7.Exit the Application.");
			System.out.println("Enter the choice:");
			choice = sc.nextInt();

			switch (choice) {
			case 1:
				System.out.println("-----Add Employee------");
				if (counter < person) {
					sc.nextLine(); // consume leftover newline
					System.out.println("Enter the Employee name");
					String name = sc.nextLine();
					System.out.println("Enter Date of birth");
					int day = sc.nextInt();
					int month = sc.nextInt();
					int year = sc.nextInt();
					MyDate dateOfBirth = new MyDate(day, month, year);
					System.out.println("Enter the ID");
					int id = sc.nextInt();
					sc.nextLine(); // consume newline before reading department
					System.out.println("Enter the department");
					String department = sc.nextLine();
					System.out.println("Enter the salary");
					double salary = sc.nextDouble();
					System.out.println("Enter the Date of joining");
					int dayj = sc.nextInt();
					int monthj = sc.nextInt();
					int yearj = sc.nextInt();
					MyDate dateOfJoining = new MyDate(dayj, monthj, yearj);

					Employee e = new Employee(name, dateOfBirth, id, department, salary, dateOfJoining);
					emp[counter++] = e;
				} else {
					System.out.println("The Employee list is full!!!");
				}
				break;

			case 2:
				for (int i = 0; i < counter; i++) {
					System.out.println(emp[i]);
				}
				break;

			case 3:
				System.out.println("Enter the Employee Id");
				int empid = sc.nextInt();
				boolean found = false;
				for (int i = 0; i < counter; i++) {
					if (emp[i].getId() == empid) {
						System.out.println("The Employee is found: " + emp[i]);
						found = true;
						break;
					}
				}
				if (!found) {
					System.out.println("The Employee is not found");
				}
				break;

			case 4:
				System.out.println("Enter the Employees joined year");
				int joinedYear = sc.nextInt();
				for (int i = 0; i < counter; i++) {
					if (emp[i].getDateOfJoining().getYear() == joinedYear) {
						System.out.println(emp[i]);
					}
				}
				break;

			case 5:
				if (counter == 0) {
					System.out.println("No employees to compare.");
					break;
				}
				System.out.println("--Maximum salary--");
				Employee max = emp[0];
				for (int i = 1; i < counter; i++) {
					if (emp[i].getSalary() > max.getSalary()) {
						max = emp[i];
					}
				}
				System.out.println("Employee: " + max);
				break;

			case 6:
				if (counter == 0) {
					System.out.println("No employees to compare.");
					break;
				}
				System.out.println("--Minimum salary--");
				Employee min = emp[0];
				for (int i = 1; i < counter; i++) {
					if (emp[i].getSalary() < min.getSalary()) {
						min = emp[i];
					}
				}
				System.out.println("Employee: " + min);
				break;
				

			default:
				System.out.println("Invalid choice");
			}
		} while (choice != 7);
	}
}

