package src.com.music.mainmenu;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import src.com.music.info.Album;
import src.com.music.info.Artist;
import src.com.music.info.Track;
import src.com.music.util.Dbutil;

public class Program {
	
	
	public static int menu(Scanner sc) {
		
		System.out.println("0.Exit");
		System.out.println("1. Add a new artist");
		System.out.println("2.Add a new album");
		System.out.println("3.Artist adds a track for the album");
		System.out.println("4. Display all artists");
		System.out.println("5. Display all albums");
		System.out.println("6. View all tracks for a given artist");
		System.out.println("7. Display all tracks");
		System.out.println("8. View all tracks for a given album");
		System.out.println("Enter the choice:");
		int choice=sc.nextInt();
		return choice;
		
	}

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int choice;
		
		while((choice=menu(sc))!=0) {
			switch(choice) {
			case 1:
				addartist(sc);
				break;
			case 2:
				addalbum(sc);
				break;
			case 3:
				addtrack(sc);
				break;
			case 4:
				displayartist();
				break;
			case 5:
				displayalbum();
				break;
			case 6:
				displaytrackbyartist(sc);
				break;
			case 7:
				displayalltrack();
				break;
			case 8:
				displaytrackbyalbum(sc);
				break;
			
			
			
			
			
			
			
			}
		}
		
		
		
		
	

	}

	private static void displaytrackbyalbum(Scanner sc) {
		System.out.println("Enter the album Id:");
		int albumid=sc.nextInt();
		
		 String sql = "SELECT * FROM Track WHERE album_id = ?";
	        try (Connection connection = Dbutil.getConnection();
	             PreparedStatement ps = connection.prepareStatement(sql)) {
	            ps.setInt(1, albumid);
	            try (ResultSet rs = ps.executeQuery()) {
	                System.out.println("\nTracks by Artist ID " + albumid + ":");
				List<Track> trackList = new ArrayList<>();
				while (rs.next()) {
					Track track=new Track();
					track.setTrack_id(rs.getInt(1));
					track.setTrack_title(rs.getString(2));
					track.setAlbum_id(rs.getInt(3));
					track.setArtist_id(rs.getInt(4));
                    trackList.add(track);
				}
				trackList.forEach(m -> System.out.println(m));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		
	}

	private static void displayalltrack() {
		String sql = "SELECT * FROM track";
		try (Connection connection = Dbutil.getConnection()) {
			try (PreparedStatement selectStatement = connection.prepareStatement(sql)) {
				ResultSet rs = selectStatement.executeQuery();
				List<Track> trackList = new ArrayList<>();
				while (rs.next()) {
					Track track=new Track();
					track.setTrack_id(rs.getInt(1));
					track.setTrack_title(rs.getString(2));
					track.setAlbum_id(rs.getInt(3));
					track.setAlbum_id(rs.getInt(4));
					trackList.add(track);
				}
				trackList.forEach(m -> System.out.println(m));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
	}

	private static void displaytrackbyartist(Scanner sc) {
		System.out.println("Enter the artist Id:");
		int artistid=sc.nextInt();
		
		 String sql = "SELECT * FROM Track WHERE artist_id = ?";
	        try (Connection connection = Dbutil.getConnection();
	             PreparedStatement ps = connection.prepareStatement(sql)) {
	            ps.setInt(1, artistid);
	            try (ResultSet rs = ps.executeQuery()) {
	                System.out.println("\nTracks by Artist ID " + artistid + ":");
				List<Track> trackList = new ArrayList<>();
				while (rs.next()) {
					Track track=new Track();
					track.setTrack_id(rs.getInt(1));
					track.setTrack_title(rs.getString(2));
					track.setAlbum_id(rs.getInt(3));
					track.setArtist_id(rs.getInt(4));
					 trackList.add(track);
				}
				trackList.forEach(m -> System.out.println(m));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}

	private static void displayalbum() {
		String sql = "SELECT * FROM album";
		try (Connection connection = Dbutil.getConnection()) {
			try (PreparedStatement selectStatement = connection.prepareStatement(sql)) {
				ResultSet rs = selectStatement.executeQuery();
				List<Album> albumList = new ArrayList<>();
				while (rs.next()) {
					Album album=new Album();
					album.setAlbum_id(rs.getInt(1));
					album.setTitle(rs.getString(2));
					albumList.add(album);
				}
				albumList.forEach(m -> System.out.println(m));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
	}

	private static void displayartist() {
		String sql = "SELECT * FROM artist";
		try (Connection connection = Dbutil.getConnection()) {
			try (PreparedStatement selectStatement = connection.prepareStatement(sql)) {
				ResultSet rs = selectStatement.executeQuery();
				List<Artist> artistList = new ArrayList<>();
				while (rs.next()) {
					Artist artist=new Artist();
					artist.setArtist_id(rs.getInt(1));
					artist.setArtistname(rs.getString(2));
					artistList.add(artist);
				}
				artistList.forEach(m -> System.out.println(m));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		
	}
	
	public static boolean exist(Connection conn,String Table,String column,int value ) throws SQLException {
		String sql="SELECT 1 FROM " + Table + " WHERE " + column + " = ?";
		PreparedStatement ps=conn.prepareStatement(sql);
		ps.setInt(1, value);
		ResultSet rs=ps.executeQuery();
		return rs.next();
		
	}
	

	private static void addtrack(Scanner sc) {
		Track track=new Track();
		track.accept(sc);
		 
	      String sql="INSERT INTO Track (track_id,title,album_id,artist_id) VALUES(?,?,?,?)";
	      try (Connection connection=Dbutil.getConnection()){
	    	  boolean albumExist=exist(connection,"album","album_id",track.getAlbum_id());
	    	  boolean artistexist=exist(connection,"artist","artist_id",track.getArtist_id());
	    	  if(!albumExist||!artistexist) {
	    		  System.out.println("The Invalid album or artist Id..");
	    		  return;
	    	  }
				try(PreparedStatement Insertstatement=connection.prepareStatement(sql)){
					Insertstatement.setInt(1, track.getTrack_id());
					Insertstatement.setString(2, track.getTrack_title());
					Insertstatement.setInt(3, track.getAlbum_id());
					Insertstatement.setInt(4, track.getArtist_id());
					
					
					Insertstatement.executeUpdate();
					System.out.println("Track Added Succesfully.....");
				}
				
	      }catch (SQLException e) {
				
				e.printStackTrace();
			}
	      
	      

	
		
	}

	private static void addalbum(Scanner sc) {
		Album album=new Album();
		
		album.accept(sc);
		String sql="INSERT INTO Album (album_id, title) VALUES(?,?)";
		try (Connection connection=Dbutil.getConnection()){
			try(PreparedStatement Insertstatement=connection.prepareStatement(sql)){
				Insertstatement.setInt(1, album.getAlbum_id());
				Insertstatement.setString(2, album.getTitle());
				
				Insertstatement.executeUpdate();
				System.out.println("Album Added Succesfully.....");
			}
			
			
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		
		
		
	}

	private static void addartist(Scanner sc) {
		Artist artist=new Artist();
		
		artist.accept(sc);
		
		String sql="INSERT INTO Artist (artist_id, name) VALUES(?,?)";
		try (Connection connection=Dbutil.getConnection()){
			try(PreparedStatement Insertstatement=connection.prepareStatement(sql)){
				Insertstatement.setInt(1, artist.getArtist_id());
				Insertstatement.setString(2, artist.getArtistname());
				
				Insertstatement.executeUpdate();
				System.out.println("Artist Added Succesfully.....");
			}
			
			
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		
		
		
	}

}
