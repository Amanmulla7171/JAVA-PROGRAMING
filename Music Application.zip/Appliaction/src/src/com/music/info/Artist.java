package src.com.music.info;

import java.util.Scanner;

public class Artist {
	
	private int artist_id;
	private String artistname;
	
	
	public Artist(int artist_id, String artistname) {
		
		this.artist_id = artist_id;
		this.artistname = artistname;
	}


	public Artist() {
	
	}


	public int getArtist_id() {
		return artist_id;
	}


	public void setArtist_id(int artist_id) {
		this.artist_id = artist_id;
	}


	public String getArtistname() {
		return artistname;
	}


	public void setArtistname(String artistname) {
		this.artistname = artistname;
	}
	public void accept(Scanner sc) {
		System.out.println("Enter the Artist Id:");
		artist_id=sc.nextInt();
		System.out.println("Enter the Artist Name:");
		artistname=sc.next();
		
	}


	@Override
	public String toString() {
		return "[artist_id=" + artist_id + ", artistname=" + artistname + "]";
	}


	
	
	
	
	

}
