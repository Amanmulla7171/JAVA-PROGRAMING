package src.com.music.info;

import java.util.Scanner;

public class Album extends Artist{
	
	public Album(int artist_id, String artistname) {
		super(artist_id, artistname);
		
	}
	private int album_id;
	private String title;
	public Album(int artist_id, String artistname, int album_id, String title) {
		super(artist_id, artistname);
		this.album_id = album_id;
		this.title = title;
	}
	
	public Album() {
		
	}

	public int getAlbum_id() {
		return album_id;
	}
	public void setAlbum_id(int album_id) {
		this.album_id = album_id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	
	public void accept(Scanner sc) {
		System.out.println("Enter the Album Id:");
		album_id=sc.nextInt();
		System.out.println("Enter the Album Title:");
		title=sc.next();
		
	}
	@Override
	public String toString() {
		return "[album_id=" + album_id + ", title=" + title + ", getArtist_id()=" + getArtist_id() + "]";
	}
	
	
	
	
	
	
	
	
	

}
