
package src.com.music.info;

import java.util.Scanner;

public class Track {
    private int track_id;
    private String track_title;
    private int album_id;   
    private int artist_id; 

   

    public Track(int track_id, String track_title, int album_id, int artist_id) {
		
		this.track_id = track_id;
		this.track_title = track_title;
		this.album_id = album_id;
		this.artist_id = artist_id;
	}

	public Track() {
		
	}

	public int getTrack_id() {
        return track_id;
    }

    public void setTrack_id(int track_id) {
        this.track_id = track_id;
    }

    public String getTrack_title() {
        return track_title;
    }

    public void setTrack_title(String track_title) {
        this.track_title = track_title;
    }

   
    
    public int getAlbum_id() {
		return album_id;
	}

	public void setAlbum_id(int album_id) {
		this.album_id = album_id;
	}

	public int getArtist_id() {
		return artist_id;
	}

	public void setArtist_id(int artist_id) {
		this.artist_id = artist_id;
	}

	public void accept(Scanner sc) {
    	System.out.println("Enter the Track Id:");
		track_id=sc.nextInt();
		System.out.println("Enter the Track Title:");
		track_title=sc.next();
		System.out.println("Enter the Album Id:");
		album_id=sc.nextInt();
		System.out.println("Enter the Artist Id:");
		artist_id=sc.nextInt();
		
	
	}

	@Override
	public String toString() {
		return "[track_id=" + track_id + ", track_title=" + track_title + ", album_id=" + album_id
				+ ", artist_id=" + artist_id + "]";
	}

   

	
}

	

	
	
	


