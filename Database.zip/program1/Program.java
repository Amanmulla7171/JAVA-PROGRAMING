package com.last.program1;

public class Program {

	public static void main(String[] args) {
		Window window=new Window();
		window.setSize(900, 900);
		window.setVisible(true);

	}

}
