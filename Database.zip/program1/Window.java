package com.last.program1;




import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

public class Window extends JFrame {
	JLabel labelName;
	JTextField textName;
	JLabel labelName1;
	JTextField textName1;
	JButton submitButton;
	JButton cancelButton;
	JLabel lableGender;
	JRadioButton radioButtonMale;
	JRadioButton radioButtonFemale;
	ButtonGroup radiogroup;
	
	JButton save;

	public Window() {
		
		super("Label and TextField and RadioButton");
		
		this.setTitle("Components");
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setLayout(null); 
		
		labelName = new JLabel("First Name : ");
		textName = new JTextField();
		labelName1 = new JLabel("Last Name : ");
		textName1 = new JTextField();
		lableGender = new JLabel("Gender :");
		radioButtonMale = new JRadioButton("Male");
		radioButtonFemale = new JRadioButton("Female");
		
		labelName.setBounds(50, 50, 80, 30);
		textName.setBounds(140, 50, 100, 30);
		this.add(labelName);
		this.add(textName);
		labelName1.setBounds(50, 100, 80, 30);
		textName1.setBounds(140, 100, 100, 30);
		this.add(labelName1);
		this.add(textName1);
		lableGender.setBounds(50, 150, 80, 30);
		radioButtonMale.setBounds(140, 150, 80, 30);
		radioButtonFemale.setBounds(250, 150, 80, 30);
		radiogroup = new ButtonGroup();
		radiogroup.add(radioButtonFemale);
		radiogroup.add(radioButtonMale);

		this.add(lableGender);
		this.add(radioButtonMale);
		this.add(radioButtonFemale);

		submitButton = new JButton("Submit"); 
		submitButton.setBounds(50, 250, 80, 30); 
		this.add(submitButton); 

		cancelButton = new JButton("Cancel");
		cancelButton.setBounds(150, 250, 80, 30);
		this.add(cancelButton);
		
		save=new JButton("save");
		save.setBounds(50,200, 80, 30);
		this.add(save);
		
		save.addActionListener(e -> {
			System.out.println("LastName - " + textName1.getText());
			textName1.setText("");
		});
		
		save.addActionListener(e -> {
			System.out.println("FirstName - " + textName.getText());
			textName.setText("");
		});
		
		
		
		radioButtonMale.addChangeListener(e -> {
			if (radioButtonMale.isSelected())
				System.out.println("Male is selected");
		});

		radioButtonFemale.addChangeListener(e -> {
			if(radioButtonFemale.isSelected())
			System.out.println("Female is selected");
		});
		

		submitButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				System.out.println("Submit Button Clicked");
			}
		});

		cancelButton.addActionListener(e -> {
			System.out.println("Cancel Button Clicked");
		});
		
	}

}
